# NVIDIA Workshop: original LLM, protein LM and genomic LM papers

**This ZIP is a verified-source DOWNLOAD KIT, not a ZIP containing the research PDFs.**
Direct retrieval of the PDF bytes was unavailable in the chat environment. The script below downloads the original publications from their source URLs **inside your internet-connected GitHub Codespace**, validates `%PDF-` magic bytes, checks file length, calculates a SHA-256, and can create a ZIP of the successfully downloaded PDFs there. It never edits source PDFs.

Scope: 23 original research papers: Transformer, GPT-1/2/3, BERT, T5; ESM-1b, ESM-2/ESMFold, ESM-3, ESM-C, ProtTrans/ProtT5, Ankh, pLM-BLAST, PLMSearch, SaProt, ProtGPT2, ProGen2; Evo 2, GenSLM, Nucleotide Transformer, DNABERT-2, HyenaDNA, Caduceus. The `papers.tsv` file contains titles, primary source pages, and direct PDF URLs. Some sources can block automatic requests; if so use the `source_page` link to save the PDF manually. Not every paper is CC BY. For any reuse, follow the license recorded by the publisher. Keep original PDFs unmodified and include citations.

## First: put this kit in the repository

1. Download `nvidia_lm_literature_kit.zip` from ChatGPT to your laptop.
2. In your browser-based GitHub Codespace, create a folder `literature_kit/` at the **top level** of `ArghavanAlisoltani/Nvidia_LLM_JH`.
3. Upload the ZIP into `literature_kit/` using VS Code Explorer; open the **second Bash terminal** and run:

```bash
cd /workspaces/Nvidia_LLM_JH
unzip -o /workspaces/Nvidia_LLM_JH/literature_kit/nvidia_lm_literature_kit.zip -d /workspaces/Nvidia_LLM_JH/literature_kit/
```

The extraction produces `/workspaces/Nvidia_LLM_JH/literature_kit/nvidia_lm_literature_kit/download_papers.py`.
If your Codespace uses a different project path, first run `pwd` in its terminal and replace `/workspaces/Nvidia_LLM_JH` throughout.

## A. Fastest way to do the workshop (only 3 papers)

This is best for `03_lit`, which is designed for *two or three papers*:

```bash
python /workspaces/Nvidia_LLM_JH/literature_kit/nvidia_lm_literature_kit/download_papers.py --workshop --repo /workspaces/Nvidia_LLM_JH
python /workspaces/Nvidia_LLM_JH/upload_check.py
```

The three starting papers are **ESM-1b (Rives), pLM-BLAST (Kaminski), PLMSearch (Liu)**. The PDFs go directly into `/workspaces/Nvidia_LLM_JH/mine/`. Check that each is `ready`. If an automatic download fails, go to its `source_page` in `papers.tsv`, download it yourself, and place the PDF manually in `mine/`.

Next open `/workspaces/Nvidia_LLM_JH/03_lit/question-mine.md` and replace its text with the content of `workshop_prompts/question-mine_remote-homology.md` (save using Ctrl-S / Cmd-S). In the **first terminal (OpenClaw chat)**:

```
/new
Read 03_lit/question-mine.md and do what it says.
```

Then in the **second terminal (Bash)**:

```bash
python /workspaces/Nvidia_LLM_JH/03_lit/check_values.py
```

Inspect `/workspaces/Nvidia_LLM_JH/results/values.csv` and `/workspaces/Nvidia_LLM_JH/results/answer.md`. Test at least one PASS row against the actual PDF. A PASS means the quote and number exist, not that the interpretation is scientifically sound.

**Important:** The `mine/` folder must contain ONLY the 2-3 papers you want to use for one run. Move previous PDFs elsewhere before starting a different hypothesis. The agent should never alter `03_lit/check_values.py`, `pages.py`, or `lit.py`.

## B. Download all primary papers and make a PDF ZIP in Codespaces

```bash
python /workspaces/Nvidia_LLM_JH/literature_kit/nvidia_lm_literature_kit/download_papers.py --all --repo /workspaces/Nvidia_LLM_JH --zip
```

Downloads to `/workspaces/Nvidia_LLM_JH/literature_library/{LLM,PLM,Genomic}/` and creates `/workspaces/Nvidia_LLM_JH/literature_papers_downloaded.zip` from the successfully retrieved PDFs. Files that cannot be downloaded are listed as FAILED with a source URL. In VS Code Explorer, right-click `literature_papers_downloaded.zip` and **Download** to save the final PDFs ZIP to your computer.

**Do not copy every paper into `mine/` at once**; it makes the workshop comparison too broad.

## C. Good research hypotheses for the workshop

- **Remote homology (best):** Do representation-based searches using pLM-BLAST and PLMSearch recover distant protein relationships that profile/alignment methods miss? Compare only on matched benchmarks, sequence identity ranges, and metrics. Use the included `question-mine_remote-homology.md`.
- **Scaling and embeddings:** Are larger protein LMs consistently better at downstream generalization? Use ESM-1b, ESM-2, ESM-C, and ProtTrans. Control for the benchmark, training data, readout method, and pooling. Use `hypothesis_scaling.md` as a guide. ESM-C currently has a 2026 preprint; do not treat newer metrics as directly comparable.
- **Genomic context:** Does longer context improve genomic benchmarks after controlling for dataset and tokenization? Compare HyenaDNA, DNABERT-2, Nucleotide Transformer, and Evo 2. Use `hypothesis_genomic_context.md` as a guide. These papers have different datasets and objectives, so count 'not comparable' rather than inventing a normalization.

Do not treat sequence identity, cosine similarity, AUROC, recall, and TM-score as interchangeable numerical outcomes. If an outcome needs an unpublished test set to be compared fairly, record that as a limit and propose a reproducible new benchmark.

## Copyright and source integrity

The script downloads from the paper authors/publishers/preprint services for private study. Not all papers allow redistribution; respect their actual license. This download kit contains no verbatim paper text and does not change any original PDF. Keep citation and version information, particularly for an arXiv/bioRxiv preprint that differs from the peer-reviewed version.
