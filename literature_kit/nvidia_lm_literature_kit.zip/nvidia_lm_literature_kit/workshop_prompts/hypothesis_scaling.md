# Alternative research hypothesis: model scale and embedding fidelity

Question: Among original ESM-1b, ESM-2/ESMFold, ESM-C and ProtTrans publications, is there matched empirical evidence that larger PLM parameter counts or more diverse training data lead to better remote homology/annotation performance? Does layer choice and pooling change this relationship?

Import only 2-3 related PDFs into `/workspaces/Nvidia_LLM_JH/mine/` for one workshop run. Copy the hypothesis into `/workspaces/Nvidia_LLM_JH/03_lit/question-mine.md`, but retain the detailed extraction/check/search instructions from `workshop_prompts/question-mine_remote-homology.md`. Extract exact quotes and units, note training data contamination, task definition, and model readout. Do not infer direct model superiority if no matched benchmark exists.
