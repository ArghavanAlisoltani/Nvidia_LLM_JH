# Alternative research hypothesis: genomic context length

Question: On matched evaluation tasks, do genome foundation models with longer sequence context (HyenaDNA, Nucleotide Transformer, DNABERT-2 and Evo 2) outperform shorter-context transformers after controlling for tokenization, dataset size, downstream fine-tuning and parameter count?

Select 2-3 original PDFs into `/workspaces/Nvidia_LLM_JH/mine/`. Edit `/workspaces/Nvidia_LLM_JH/03_lit/question-mine.md` with this question and keep the 4-step exact-quotation checking protocol from the workshop file. Extract context length, tokenization resolution, benchmark, metric, conditions and model size as separate traceable rows. Avoid naive comparisons on different species, tasks, or datasets. A 'cannot be compared' conclusion can be the scientifically correct result.
