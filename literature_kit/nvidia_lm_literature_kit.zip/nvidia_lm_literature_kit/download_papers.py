#!/usr/bin/env python3
"""Download primary-source PDFs into local storage or 03_lit workshop mine/.
Usage: python download_papers.py --workshop --repo /workspaces/Nvidia_LLM_JH
       python download_papers.py --all --repo /workspaces/Nvidia_LLM_JH --zip
       python download_papers.py --category PLM --repo /workspaces/Nvidia_LLM_JH
       python download_papers.py --ids esm1b plmblast plmsearch --repo /workspaces/Nvidia_LLM_JH
No third-party Python package required. Does not modify workshop 03_lit tools.
"""
import argparse,csv,hashlib,json,sys,time,urllib.request,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
MANIFEST=ROOT/'papers.tsv'
WORKSHOP_IDS={'esm1b','plmblast','plmsearch'}

def get_papers():
 with MANIFEST.open(newline='',encoding='utf-8') as f: return list(csv.DictReader(f,delimiter='\t'))

def download(url,dest,attempts=2):
 dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists() and dest.stat().st_size > 5000 and dest.open('rb').read(5)==b'%PDF-':
  return 'existing',dest.stat().st_size,hashlib.sha256(dest.read_bytes()).hexdigest()
 error=None
 for attempt in range(attempts):
  try:
   req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (educational literature review)','Accept':'application/pdf,*/*'})
   with urllib.request.urlopen(req,timeout=40) as r:
    data=r.read(35*1024*1024+1)
   if len(data)>35*1024*1024: raise ValueError('PDF exceeded 35 MB safety limit')
   if not data.startswith(b'%PDF-'): raise ValueError('URL returned HTML/error rather than a PDF; download manually from source page')
   tmp=dest.with_suffix('.pdf.partial');tmp.write_bytes(data);tmp.replace(dest)
   return 'downloaded',len(data),hashlib.sha256(data).hexdigest()
  except Exception as e:
   error=str(e)
   if attempt+1<attempts: time.sleep(1)
 raise RuntimeError(error)

def main():
 p=argparse.ArgumentParser(description=__doc__)
 sel=p.add_mutually_exclusive_group(required=True)
 sel.add_argument('--all',action='store_true',help='Download all catalogue entries to library')
 sel.add_argument('--workshop',action='store_true',help='Download 3 comparable remote homology papers to mine/')
 sel.add_argument('--category',choices=['LLM','PLM','Genomic'],help='Only this subject area')
 sel.add_argument('--ids',nargs='+',metavar='ID',help='One or more paper IDs from papers.tsv')
 p.add_argument('--repo',type=Path,default=Path('/workspaces/Nvidia_LLM_JH'),help='Absolute path to workshop repository')
 p.add_argument('--zip',action='store_true',help='Also ZIP successfully downloaded PDFs into repository root')
 p.add_argument('--dry-run',action='store_true')
 args=p.parse_args()
 all_rows=get_papers();valid_ids={r['id'] for r in all_rows}
 if args.ids and set(args.ids)-valid_ids: p.error('Unknown paper id(s): '+', '.join(sorted(set(args.ids)-valid_ids)))
 if args.workshop: chosen=[r for r in all_rows if r['id'] in WORKSHOP_IDS]
 elif args.category: chosen=[r for r in all_rows if r['category']==args.category]
 elif args.ids: chosen=[r for r in all_rows if r['id'] in set(args.ids)]
 else: chosen=all_rows
 repo=args.repo.resolve()
 if not args.dry_run and not (repo/'03_lit'/'README.md').exists(): p.error(f'Not a workshop repository: {repo}. Use --repo /absolute/path/to/Nvidia_LLM_JH')
 dest=repo/'mine' if args.workshop else repo/'literature_library'
 print('Repository:',repo,'\nOutput folder:',dest,'\nSelected:',len(chosen))
 log=[];downloaded=[]
 for r in chosen:
  filename=r['id']+'.pdf'
  folder=dest if args.workshop else dest/r['category']
  filepath=folder/filename
  print(f"{r['id']:24} {r['title']}")
  if args.dry_run: print('  ->',filepath,'URL:',r['pdf_url']);continue
  try:
   status,n,sha=download(r['pdf_url'],filepath)
   downloaded.append(filepath)
   print(f'  {status.upper()} {n:,} bytes SHA256={sha[:16]}...')
   log.append({**r,'status':status,'file':str(filepath),'bytes':n,'sha256':sha})
  except Exception as e:
   print('  FAILED:',e,'\n  Manual source:',r['source_page'])
   log.append({**r,'status':'failed','error':str(e)})
 if args.dry_run:return 0
 logfile=(repo/'mine'/'pdf_download_log.json') if args.workshop else (repo/'literature_library'/'download_log.json')
 logfile.parent.mkdir(parents=True,exist_ok=True)
 logfile.write_text(json.dumps(log,indent=2,ensure_ascii=False),encoding='utf-8')
 if args.zip and downloaded:
  output=repo/'literature_papers_downloaded.zip'
  with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
   for pdf in downloaded:z.write(pdf,pdf.relative_to(repo))
   z.write(MANIFEST,'papers.tsv')
   z.write(logfile,logfile.relative_to(repo))
  print('\nZIP created:',output)
 print(f'\nDownloaded or confirmed: {len(downloaded)}/{len(chosen)}; failed: {len(chosen)-len(downloaded)}')
 print('Download log:',logfile)
 if args.workshop: print('Next: python '+str(repo/'upload_check.py'))
 return 0 if downloaded else 2
if __name__=='__main__':sys.exit(main())
